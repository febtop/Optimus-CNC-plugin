class globalvar:
  socket=None