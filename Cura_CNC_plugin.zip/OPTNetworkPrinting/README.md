# UM3NetworkPrintingPlugin
Plugin to enable wifi printing from Cura to UM3.

Intructions
----
- Clone repo into [Cura installation folder]/plugins/UM3NetworkPrinting (Or somewhere else and add a link..)
- pip3 install python3-zeroconf
