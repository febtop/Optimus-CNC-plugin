	

STEP_2="\tStep2:\n1.Change cutter tool\n2.Fasten your stock/board\n3.Place the calibration cylinder on the stock/board\n4.Connect the clip to the cutter tool\n5.Check electric connection with buzzer\n6.Input the size of calibration area\n7.Press 'Next' to reset CNC."
STEP_3="\tStep3:\nMove the cutting tool to the center of the stock/board\n"
STEP_4="\tStep4:\n1.Remove clip from cutter tool\n2.Start spindle motor\n3.Press 'SD Card' to find out gcode file at SD Card\n4.Select file to print."
STEP_5="\tStep5:\n1.Press 'Next' to start print.\n2.After Caver,you can chose new gcode caver again."

Change_Cutter_Message="Make Sure you are already change cutter,set the measure block to specify position and you have already set your size!Press 'OK' to start find plane!"
After_FindPlane_Message="open the motor,set right speed!"